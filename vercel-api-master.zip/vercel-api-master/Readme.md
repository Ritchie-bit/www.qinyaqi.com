# Vercel API

Document see [serverless functions](https://vercel.com/docs/concepts/functions/serverless-functions/quickstart)。

## API

``` bash
$ curl https://vercel-api.shanyue.vercel.app/api?name=shanyue
Hello, shanyue

$ curl https://vercel-api.shanyue.vercel.app/api/users/3
Hello, shanyue
```
